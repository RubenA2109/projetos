// server.js
const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Base de dados em memória (temporária)
let scores = [];

// Rota GET - listar todos os scores
app.get("/api/scores/", (req, res) => {
  res.json(scores);
});

// Rota POST - adicionar um novo score
app.post("/api/scores/", (req, res) => {
  const { datascore, nickname, score, game } = req.body;

  if (!nickname || score === undefined || !game) {
    return res.status(400).json({ error: "Dados inválidos." });
  }

  scores.push({ datascore, nickname, score, game });
  console.log("Novo score recebido:", { nickname, score, game });

  res.status(201).json({ message: "Score recebido com sucesso!" });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor a correr em http://localhost:${PORT}`);
});
